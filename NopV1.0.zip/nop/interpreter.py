import sys
import time
import re

def run_nop_script(filename):
    if not filename.endswith('.np'):
        print(f"Syntax Mistake: file '{filename}' file must ne .np!")
        return

    try:
        with open(filename, 'r', encoding='utf-8') as f:
            lines = f.readlines()
    except FileNotFoundError:
        print(f"Syntax Mistake: '{filename}' nebyl nalezen.")
        return

    for line_num, line in enumerate(lines, 1):
        line = line.strip()
        
        # Ignorujeme prázdné řádky
        if not line:
            continue

        # Příkaz: Nop "text"
        nop_match = re.match(r'^nop\s+"(.*)"$', line, re.IGNORECASE)
        if nop_match:
            print(nop_match.group(1))
            continue

        # Příkaz: wait X
        wait_match = re.match(r'^wait\s+([0-9]+(?:\.[0-9]+)?)$', line, re.IGNORECASE)
        if wait_match:
            seconds = float(wait_match.group(1))
            time.sleep(seconds)
            continue

        # Příkaz: exit
        if line.lower() == 'exit':
            break

        # Syntaktická chyba
        print(f"Syntax Mistake: on line {line_num}: {line}")
        break

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Použití: python nop.py <soubor.np>")
    else:
        run_nop_script(sys.argv[1])